
import "./App.css";

// import Nav3 from "./mobeCom/Nav3";
// import FormTodo from ".././src/NewTodoProject/FormTodo";
import FormPage from "./FormPage";
import NewFormPage from "./NewFormPage";

function App() {
  return (
  
      <>
        {/* <Nav3/> */}
        {/* <FormPage/> */}
        {/* <FormTodo/> */}
        <NewFormPage/>
              </>
   
  );
}

export default App;
