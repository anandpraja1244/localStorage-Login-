
import "./App.css";
import FormPage from "./FormPage";

function App() {
  return (
    <div className="App">
      <>
        <FormPage />
      </>
    </div>
  );
}

export default App;
